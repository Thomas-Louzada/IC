
bl_info = {
    "name": "Gerador de Sólidos Automatizado",
    "blender": (2, 80, 0),
    "category": "Object",
}

import bpy
import os
import numpy as np
import math

# Função para carregar sólidos de um arquivo
def carregar_solidos(arquivo):
    solidos = {}
    with open(arquivo, 'r') as f:
        linhas = f.readlines()
        for linha in linhas:
            if " | n=" in linha:
                partes = linha.split(" | n=")
                nome_e_faces = partes[0].strip()
                n = int(partes[1].strip())
                nome, faces_raw = nome_e_faces.split(" - ")
                faces = eval(faces_raw)
                solidos[nome] = (faces, n)
    return solidos

# Corrigir orientação das faces (heurística simples baseada na normal)
def corrigir_orientacao_faces(faces):
    return [face if face[0] < face[-1] else list(reversed(face)) for face in faces]

# Atualizar objeto no Blender
def atualizar_objeto(vc, edges, faces):
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete()
    mesh = bpy.data.meshes.new("sólido")
    obj = bpy.data.objects.new("sólido", mesh)
    bpy.context.collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    mesh.from_pydata(vc.tolist(), edges, faces)
    mesh.update()
    bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
    return obj

# Distância ao quadrado
def d2(vc, i, j):
    return np.sum((vc[i] - vc[j]) ** 2)

def calcular_d2(n, i, j):
    if n == 3:
        return 1
    elif n == 4:
        return (math.sqrt(2) ** 2) if abs(i - j) == 2 else 1
    elif n == 5:
        return (((1 + math.sqrt(5)) / 2) ** 2) if abs(i - j) in [2, 3] else 1
    elif n == 6:
        return (math.sqrt(3) ** 2) if abs(i - j) == 3 else (4 if abs(i - j) == 2 else 1)
    elif n == 8:
        if abs(i - j) == 4:
            return (1 / math.sqrt(1/2 - math.sqrt(2)/4)) ** 2
        elif abs(i - j) == 3:
            return (math.sqrt(math.sqrt(2)/4 + 1/2) / math.sqrt(1/2 - math.sqrt(2)/4)) ** 2
        elif abs(i - j) == 2:
            return (math.sqrt(2) / (2 * math.sqrt(1/2 - math.sqrt(2)/4))) ** 2
        else:
            return 1
    elif n == 10:
        if abs(i - j) == 5:
            return (2 / (-1/2 + math.sqrt(5)/2)) ** 2
        elif abs(i - j) == 4:
            return (2 * math.sqrt(math.sqrt(5)/8 + 5/8) / (-1/2 + math.sqrt(5)/2)) ** 2
        elif abs(i - j) == 3:
            return (2 * (1/4 + math.sqrt(5)/4) / (-1/2 + math.sqrt(5)/2)) ** 2
        elif abs(i - j) == 2:
            return (2 * math.sqrt(5/8 - math.sqrt(5)/8) / (-1/2 + math.sqrt(5)/2)) ** 2
        else:
            return 1

def calcular_incidencias(nv, segmentos):
    incidencias = [[] for _ in range(nv)]
    for idx, (i, j, _) in enumerate(segmentos):
        incidencias[i].append(idx)
        incidencias[j].append(idx)
    return incidencias

def gradiente(vc, segmentos, incidencias):
    grad = np.zeros_like(vc)
    for idx, (i, j, d2_valor) in enumerate(segmentos):
        dist = np.sqrt(d2(vc, i, j))
        if dist == 0:
            continue
        grad[i] += 2 * (dist - math.sqrt(d2_valor)) * (vc[i] - vc[j]) / dist
        grad[j] += 2 * (dist - math.sqrt(d2_valor)) * (vc[j] - vc[i]) / dist
    return grad

class GerarSolidoOperator(bpy.types.Operator):
    bl_idname = "object.gerar_solido_popup"
    bl_label = "Gerar Sólido por Nome"
    bl_options = {'REGISTER', 'UNDO'}

    nome_solido: bpy.props.StringProperty(name="Nome do Sólido", default="J84")

    def execute(self, context):
        pasta = os.path.dirname(bpy.data.filepath)
        caminho_arquivo = os.path.join(pasta, "faces.txt")
        solidos = carregar_solidos(caminho_arquivo)

        if self.nome_solido not in solidos:
            self.report({'ERROR'}, f"Sólido '{self.nome_solido}' não encontrado.")
            return {'CANCELLED'}

        faces_originais, n = solidos[self.nome_solido]
        faces = corrigir_orientacao_faces(faces_originais)

        num_vertices = max(max(f) for f in faces) + 1
        vc = np.random.uniform(-1, 1, (num_vertices, 3))
        segmentos = []
        for f in faces:
            tamanho = len(f)
            for i in range(tamanho):
                for j in range(i + 1, tamanho):
                    d2_valor = calcular_d2(tamanho, f[i], f[j])
                    segmentos.append([f[i], f[j], d2_valor])

        incidencias = calcular_incidencias(num_vertices, segmentos)
        velocity = np.zeros_like(vc)
        alpha = 0.01
        tolerance = 1e-10
        max_iter = 10000
        norma_grad = 1.0
        i = 0
        edges = []

        while norma_grad > tolerance and i < max_iter:
            i += 1
            grad = gradiente(vc, segmentos, incidencias)
            norma_grad = np.linalg.norm(grad)
            velocity -= alpha * grad
            velocity *= 0.99
            vc += velocity
            atualizar_objeto(vc, edges, faces)

        # Exportar como .obj
        nome_arquivo = os.path.join(pasta, f"{self.nome_solido}.obj")
        bpy.ops.export_scene.obj(filepath=nome_arquivo, use_selection=True)
        self.report({'INFO'}, f"Sólido exportado para {nome_arquivo}")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

def menu_func(self, context):
    self.layout.operator(GerarSolidoOperator.bl_idname)

def register():
    bpy.utils.register_class(GerarSolidoOperator)
    bpy.types.VIEW3D_MT_object.append(menu_func)

def unregister():
    bpy.utils.unregister_class(GerarSolidoOperator)
    bpy.types.VIEW3D_MT_object.remove(menu_func)

if __name__ == "__main__":
    register()
