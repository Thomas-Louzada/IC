import os
from core.loader import carregar_solidos
from core.orientacao import corrigir_orientacao_faces
from core.geometria import gradiente, gerar_segmentos
import numpy as np

def main():
    # Garante que faces.txt seja buscado no mesmo diretório deste script:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    faces_path = os.path.join(script_dir, 'faces.txt')

    solidos = carregar_solidos(faces_path)
    nome = input("Digite o nome do sólido: ")
    if nome not in solidos:
        print(f"Sólido '{nome}' não encontrado em faces.txt.")
        return
    faces, _ = solidos[nome]
    faces = corrigir_orientacao_faces(faces)
    segmentos = gerar_segmentos(faces)

    nv = int(segmentos[:, :2].max()) + 1
    vc = np.random.uniform(-1, 1, (nv, 3))
    vel = np.zeros_like(vc)
    alpha = 0.01
    tol = 1e-16
    max_iter = 10000

    print(f"Iniciando otimização do sólido '{nome}'")
    print(f"Tolerância de parada: {tol}\n")

    for it in range(1, max_iter + 1):
        max_step = 0.1  
        g = gradiente(vc, segmentos, max_step=max_step)
        norm_g = np.linalg.norm(g)

        # Print somente a cada 100 iterações
        if it % 1000000 == 0:
            print(f"Iteração {it:5d} | ||grad|| = {norm_g:.6e}")

        if norm_g <= tol:
            print(f"\nConvergiu em {it} iterações (||grad|| = {norm_g:.6e} ≤ tol).")
            break

        # Atualização de velocidade e posição
        vel = vel * 0.99 - alpha * g
        vc += vel

    else:
        # Caso o loop termine sem convergir
        print(f"\nNão convergiu em {max_iter} iterações (||grad|| = {norm_g:.6e}).")

    # Print das coordenadas finais
    print("\nCoordenadas finais:")
    for idx, coord in enumerate(vc):
        print(f"  v[{idx}]: {coord}")

    # --- Aqui entra a integração com distancias.py ---
    from core.distancias import calcular_distancias, salvar_solido

    # Converte numpy array -> lista de tuplas
    vertices = [tuple(v) for v in vc]

    distancias = calcular_distancias(vertices)
    salvar_solido(nome, vertices, distancias)


if __name__ == '__main__':
    main()
