import os
import time
from core.loader import carregar_solidos
from core.orientacao import corrigir_orientacao_faces
from core.geometria import gradiente, gerar_segmentos
from core.distancias import calcular_distancias, salvar_solido
import numpy as np

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    faces_path = os.path.join(script_dir, 'faces.txt')

    solidos = carregar_solidos(faces_path)
    nome = input("Digite o nome do sólido: ").strip()
    if nome not in solidos:
        print(f"Sólido '{nome}' não encontrado em faces.txt.")
        return
    faces, _ = solidos[nome]
    faces = corrigir_orientacao_faces(faces)
    segmentos = gerar_segmentos(faces)

    # --- Quantas repetições (m) ---
    m_input = input("Quantas vezes deseja gerar o sólido? (Enter = infinito) ").strip()
    try:
        m = None if m_input == "" else int(m_input)
    except Exception:
        print("Entrada inválida para 'm'. Usando m = 1.")
        m = 1

    # --- Parâmetros do otimizador ---
    alpha = 0.01           
    grad_tol = 1e-10        
    max_iter = 10000000       
    max_step = 0.1         
    save_nonconverged = False  

    rep = 0
    encontrados = 0   # contador de mínimos distintos

    try:
        while True:
            rep += 1
            if m is not None and rep > m:
                print("Finalizado número de repetições solicitado.")
                break

            suffix = f"/{m}" if m is not None else ""
            print(f"\n=== Execução {rep}{suffix} para '{nome}' ===")

            nv = int(segmentos[:, :2].max()) + 1
            vc = np.random.uniform(-1, 1, (nv, 3))   
            vel = np.zeros_like(vc)

            converged = False
            start_time = time.time()
            for it in range(1, max_iter + 1):
                g = gradiente(vc, segmentos, max_step=max_step)
                norm_g = np.linalg.norm(g)

                if it % 100 == 0:
                    print(f"Iter {it:6d} | ||grad|| = {norm_g:.6e}")

                if norm_g <= grad_tol:
                    converged = True
                    print(f"Convergiu em {it} iterações (||grad|| = {norm_g:.6e}).")
                    break

                vel = vel * 0.99 - alpha * g
                vc += vel

            elapsed = time.time() - start_time
            if not converged:
                print(f"Não convergiu em {max_iter} iterações (||grad|| = {norm_g:.6e}). Tempo: {elapsed:.2f}s")

            if converged or save_nonconverged:
                vertices = [tuple(v) for v in vc]
                distancias = calcular_distancias(vertices)
                saved = salvar_solido(nome, vertices, distancias, tol=1e-6)
                if saved:
                    encontrados += 1
                    print("Sólido salvo (novo).")
                else:
                    print("Sólido não salvo (provável duplicata dentro da tolerância).")
            else:
                print("Execução descartada (não convergiu e save_nonconverged=False).")

    except KeyboardInterrupt:
        print("\nInterrompido pelo usuário (Ctrl+C).")

    # --- Resumo final ---
    print(f"\nResumo: Foram encontrados {encontrados} mínimos distintos.")

if __name__ == '__main__':
    main()