import os
import time
import numpy as np
from core.loader import carregar_solidos
from core.orientacao import corrigir_orientacao_faces
from core.geometria import gradiente, gerar_segmentos
from core.distancias import calcular_distancias, salvar_solido

# --- Função energia ---
def energia(vc, segmentos):
    diffs = []
    for (i, j, d) in segmentos:
        vi, vj = vc[int(i)], vc[int(j)]
        diffs.append((np.linalg.norm(vi - vj)**2 - d) ** 2)
    return 0.5 * sum(diffs)

# --- Hessiana por diferenças finitas ---
def hessiana(vc, segmentos, eps=1e-6):
    n = vc.size
    H = np.zeros((n, n))
    g0 = gradiente(vc, segmentos).reshape(-1)
    for k in range(n):
        vc_pert = vc.copy().reshape(-1)
        vc_pert[k] += eps
        vc_pert = vc_pert.reshape(vc.shape)
        g1 = gradiente(vc_pert, segmentos).reshape(-1)
        H[:, k] = (g1 - g0) / eps
    return H

# --- Salvar solução completa em 3 arquivos ---
def salvar_solucao(nome_solucao, tipo, nome_solido, vc, distancias, autovalores):
    base = tipo.lower()  # "global" ou "local"

    # 1) pontos
    with open(f"{base}_pontos.txt", "a", encoding="utf-8") as f:
        f.write(f"{nome_solucao} ({nome_solido})\n")
        for v in vc:
            f.write(f"{v.tolist()}\n")
        f.write("-"*40 + "\n")

    # 2) distâncias
    with open(f"{base}_distancias.txt", "a", encoding="utf-8") as f:
        f.write(f"{nome_solucao} ({nome_solido})\n")
        for d in distancias:
            f.write(f"{d:.6e}\n")
        f.write("-"*40 + "\n")

    # 3) autovalores
    with open(f"{base}_autovalores.txt", "a", encoding="utf-8") as f:
        f.write(f"{nome_solucao} ({nome_solido})\n")
        f.write(" ".join(f"{l:.6e}" for l in autovalores))
        f.write("\n" + "-"*40 + "\n")

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    faces_path = os.path.join(script_dir, 'faces.txt')

    solidos = carregar_solidos(faces_path)
    nome = input("Digite o nome do sólido: ").strip()
    if nome not in solidos:
        print(f"Sólido '{nome}' não encontrado em faces.txt.")
        return
    faces, _ = solidos[nome]
    faces = corrigir_orientacao_faces(faces)
    segmentos = gerar_segmentos(faces)

    # --- Quantas repetições (m) ---
    m_input = input("Quantas vezes deseja gerar o sólido? (Enter = infinito) ").strip()
    try:
        m = None if m_input == "" else int(m_input)
    except Exception:
        print("Entrada inválida para 'm'. Usando m = 1.")
        m = 1

    # --- Parâmetros do otimizador ---
    alpha = 0.01
    grad_tol = 1e-12
    max_iter = 1000000
    max_step = 0.1
    save_nonconverged = False

    rep = 0
    encontrados = 0   # contador de mínimos distintos
    contador_globais = 0
    contador_locais = 0

    try:
        while True:
            rep += 1
            if m is not None and rep > m:
                print("Finalizado número de repetições solicitado.")
                break

            suffix = f"/{m}" if m is not None else ""
            print(f"\n=== Execução {rep}{suffix} para '{nome}' ===")

            nv = int(segmentos[:, :2].max()) + 1
            vc = np.random.uniform(-1, 1, (nv, 3))
            vel = np.zeros_like(vc)

            converged = False
            start_time = time.time()
            for it in range(1, max_iter + 1):
                g = gradiente(vc, segmentos, max_step=max_step)
                norm_g = np.linalg.norm(g)

                if it % 10000 == 0:
                    print(f"Iter {it:6d} | ||grad|| = {norm_g:.6e}")

                if norm_g <= grad_tol:
                    converged = True
                    print(f"Convergiu em {it} iterações (||grad|| = {norm_g:.6e}).")
                    break

                vel = vel * 0.99 - alpha * g
                vc += vel

            elapsed = time.time() - start_time
            fval = energia(vc, segmentos)
            distancias = calcular_distancias([tuple(v) for v in vc])
            H = hessiana(vc, segmentos)
            autovalores = np.linalg.eigvalsh(H)

            if abs(fval) < 1e-6:
                tipo = "global"
                contador_globais += 1
                nome_solucao = f"solucao_global_{contador_globais}"
            else:
                tipo = "local"
                contador_locais += 1
                nome_solucao = f"solucao_local_{contador_locais}"

            print(f"{nome_solucao} encontrado: f={fval:.6e}")
            salvar_solucao(nome_solucao, tipo, nome, vc, distancias, autovalores)

            if not converged:
                print(f"Não convergiu em {max_iter} iterações (||grad|| = {norm_g:.6e}). Tempo: {elapsed:.2f}s")

            # --- Salvamento normal dos sólidos ---
            if converged or save_nonconverged:
                vertices = [tuple(v) for v in vc]
                saved = salvar_solido(nome, vertices, distancias, tol=1e-6)
                if saved:
                    encontrados += 1
                    print("Sólido salvo (novo).")
                else:
                    print("Sólido não salvo (provável duplicata dentro da tolerância).")
            else:
                print("Execução descartada (não convergiu e save_nonconverged=False).")

    except KeyboardInterrupt:
        print("\nInterrompido pelo usuário (Ctrl+C).")

    # --- Resumo final ---
    print(f"\nResumo: Foram encontrados {encontrados} mínimos distintos.")

if __name__ == '__main__':
    main()
