bl_info = {
    "name": "Gerador de Sólidos Automatizado (Animação e Vídeo via Câmera)",
    "blender": (2, 80, 0),
    "category": "Object",
}

import bpy
import os
import json
import numpy as np
import math
import shutil
import glob
import time
from collections import defaultdict, deque

from core.loader import carregar_solidos
from core.orientacao import corrigir_orientacao_faces
from core.geometria import gradiente, gerar_segmentos
from core.assinatura import compute_distance_signature

class GerarSolidoOperator(bpy.types.Operator):
    bl_idname = 'object.gerar_solido_popup'
    bl_label = 'Gerar, Animar e Gravar (Câmera)'
    bl_options = {'REGISTER'}

    faces_path: bpy.props.StringProperty(subtype='FILE_PATH')
    nome_solido: bpy.props.StringProperty()
    video_path: bpy.props.StringProperty(subtype='FILE_PATH')
    catalog_path: bpy.props.StringProperty(
        name="Caminho do Catalog.json",
        description="Local onde o arquivo de catálogo será salvo",
        subtype='FILE_PATH'
    )
    tol_exp: bpy.props.IntProperty(default=10, min=0)
    alpha: bpy.props.FloatProperty(default=0.01, min=0.0)
    max_iter: bpy.props.IntProperty(default=10000, min=1)
    angle_step: bpy.props.FloatProperty(name="Grau por 10 iterações", default=0.0, min=0.0, max=360.0)

    _timer = None
    _vc = None
    _vel = None
    _segments = None
    _faces = None
    _obj = None
    _it = 0
    _tol = 0.0
    _frame = 1
    _angle_rad = 0.0
    _target = None
    _out_dir = None
    _stopped_by_tol = False
    seen_signatures = set()

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'faces_path')
        layout.prop(self, 'nome_solido')
        layout.prop(self, 'video_path')
        layout.prop(self, 'catalog_path')
        layout.prop(self, 'tol_exp')
        layout.prop(self, 'alpha')
        layout.prop(self, 'max_iter')
        layout.prop(self, 'angle_step')

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        scene = context.scene
        if scene.sequence_editor:
            scene.sequence_editor_clear()

        timestamp = int(time.time())
        self._out_dir = bpy.path.abspath(self.video_path) + f'_{self.nome_solido}_{timestamp}'
        os.makedirs(self._out_dir, exist_ok=True)

        # Resolve caminho de catalog.json (pode ser arquivo ou diretório)
        if self.catalog_path:
            path = bpy.path.abspath(self.catalog_path)
            if os.path.isdir(path):
                path = os.path.join(path, "catalog.json")
            self._catalog_file = path
        else:
            addon_dir = os.path.dirname(__file__)
            self._catalog_file = os.path.join(addon_dir, "catalog.json")

        # Carrega catálogo prévio apenas se for um arquivo existente
        if os.path.isfile(self._catalog_file):
            with open(self._catalog_file, 'r') as f:
                GerarSolidoOperator.seen_signatures = set(json.load(f))
        else:
            GerarSolidoOperator.seen_signatures = set()

        scene.render.image_settings.file_format = 'PNG'

        fpath = bpy.path.abspath(self.faces_path) if self.faces_path else os.path.join(os.path.dirname(__file__), 'faces.txt')
        sol = carregar_solidos(fpath)
        if self.nome_solido not in sol:
            self.report({'ERROR'}, 'Sólido não encontrado no arquivo')
            return {'CANCELLED'}
        faces0, _ = sol[self.nome_solido]
        self._faces = corrigir_orientacao_faces(faces0)

        self._segments = gerar_segmentos(self._faces)
        edges, seen = [], set()
        for face in self._faces:
            for i in range(len(face)):
                a, b = face[i], face[(i+1) % len(face)]
                if (a,b) not in seen:
                    edges.append((a,b)); seen.update({(a,b),(b,a)})

        nv = int(self._segments[:, :2].max()) + 1
        self._vc = np.random.uniform(-1, 1, (nv, 3))
        self._vel = np.zeros_like(self._vc)

        mesh = bpy.data.meshes.new(f"sol_{self.nome_solido}")
        self._obj = bpy.data.objects.new(f"sol_{self.nome_solido}", mesh)
        context.collection.objects.link(self._obj)
        mesh.from_pydata(self._vc.tolist(), edges, self._faces)
        mesh.update()

        empty = bpy.data.objects.new("Camera_Target", None)
        empty.location = self._obj.location
        context.collection.objects.link(empty)
        self._target = empty
        cam = context.scene.camera or bpy.data.objects.new("Camera_Solido", bpy.data.cameras.new("Cam"))
        if not context.scene.camera:
            context.collection.objects.link(cam)
            context.scene.camera = cam
        cam.parent = empty; cam.location = (0, -5, 0)
        tr = cam.constraints.new('TRACK_TO'); tr.target = empty
        tr.track_axis = 'TRACK_NEGATIVE_Z'; tr.up_axis = 'UP_Y'

        self._it = 0; self._frame = 1; self._angle_rad = 0.0
        self._tol = 10 ** (-self.tol_exp)
        self._stopped_by_tol = False

        wm = context.window_manager
        wm.progress_begin(0, self.max_iter)
        self._timer = wm.event_timer_add(0.05, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'TIMER':
            for _ in range(10):
                g = gradiente(self._vc, self._segments)
                grad_norm = np.linalg.norm(g)
                self._it += 1
                context.window_manager.progress_update(self._it)
                if self._it >= self.max_iter or grad_norm <= self._tol:
                    self._stopped_by_tol = (grad_norm <= self._tol)
                    atualizar_mesh = lambda: None  # placeholder
                    mesh = self._obj.data
                    mesh.vertices.foreach_set('co', self._vc.ravel())
                    mesh.update()
                    return self.finish(context)
                self._vel = self._vel * 0.99 - self.alpha * g
                self._vc += self._vel

            # Atualiza diretamente a malha sem mudar o modo
            mesh = self._obj.data
            mesh.vertices.foreach_set('co', self._vc.ravel())
            mesh.update()

            context.scene.frame_set(self._frame)
            img_path = os.path.join(self._out_dir, f"frame_{self._frame:04d}.png")
            context.scene.render.filepath = img_path
            bpy.ops.render.render(write_still=True)

            if self.angle_step > 0.0:
                self._angle_rad += math.radians(self.angle_step)
                self._target.rotation_euler = (0, 0, self._angle_rad)

            self._frame += 1
        return {'PASS_THROUGH'}

    def finish(self, context):
        signature = compute_distance_signature(self._vc)
        if signature in GerarSolidoOperator.seen_signatures:
            self.report({'INFO'}, f"Sólido '{self.nome_solido}' duplicado — descartado")
            with open(self._catalog_file, 'w') as f:
                json.dump(list(GerarSolidoOperator.seen_signatures), f)
            return {'CANCELLED'}
        else:
            GerarSolidoOperator.seen_signatures.add(signature)
            with open(self._catalog_file, 'w') as f:
                json.dump(list(GerarSolidoOperator.seen_signatures), f)

        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        wm.progress_end()

        scene = context.scene
        if not scene.sequence_editor:
            scene.sequence_editor_create()
        seq = scene.sequence_editor.sequences
        files = sorted(glob.glob(os.path.join(self._out_dir, 'frame_*.png')))
        for idx, filepath in enumerate(files, start=1):
            seq.new_image(name=f"Frame{idx:04d}", filepath=filepath, channel=1, frame_start=idx)

        scene.render.use_sequencer = True
        scene.render.filepath = bpy.path.abspath(self.video_path)
        scene.render.ffmpeg.format = 'MPEG4'
        scene.render.ffmpeg.codec = 'H264'
        scene.render.ffmpeg.constant_rate_factor = 'HIGH'
        scene.frame_start = 1
        scene.frame_end = self._frame - 1

        bpy.ops.render.render(animation=True, use_viewport=False)
        shutil.rmtree(self._out_dir)

        motivo = 'tolerância' if self._stopped_by_tol else 'número máximo de iterações'
        self.report({'INFO'}, f"Concluído em {self._it} iterações. Parado por {motivo}.")
        return {'FINISHED'}

    def cancel(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            context.window_manager.progress_end()
        self.report({'WARNING'}, 'Execução cancelada pelo usuário.')
        return {'CANCELLED'}

def menu_func(self, context):
    self.layout.operator(GerarSolidoOperator.bl_idname)

def register():
    bpy.utils.register_class(GerarSolidoOperator)
    bpy.types.VIEW3D_MT_object.append(menu_func)

def unregister():
    bpy.utils.unregister_class(GerarSolidoOperator)
    bpy.types.VIEW3D_MT_object.remove(menu_func)

if __name__ == '__main__':
    register()
