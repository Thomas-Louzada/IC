# Gerador de Sólidos Automatizado

## Estrutura do Projeto

```
gerador_solidos/
│
├── core/
│   ├── __init__.py
│   ├── geometria.py         # Cálculo de distâncias, segmentos e gradiente
│   ├── orientacao.py        # Correção de orientação das faces
│   ├── loader.py            # Carregamento do arquivo de faces
│   └── assinatura.py        # Cálculo de assinatura de distância
│
├── blender_addon.py         # Add-on para Blender, importando 'core'
├── standalone.py            # Script Python puro para otimização de sólidos
└── faces.txt                # Arquivo de faces (insira seus dados aqui)
```

## Módulos

### core/loader.py
- `carregar_solidos(arquivo)`: Lê o `faces.txt` e retorna um dicionário `{nome: (faces, n)}`.

### core/orientacao.py
- `corrigir_orientacao_faces(faces)`: Ajusta a direção das faces para uma orientação consistente.

### core/geometria.py
- `calcular_d2(n, i, j)`: Distância ao quadrado esperada entre vértices em um polígono regular.
- `gerar_segmentos(faces)`: Gera segmentos (i, j, d2) a partir das faces.
- `gradiente(vc, segmentos)`: Calcula o gradiente para otimização.

### core/assinatura.py
- `compute_distance_signature(vc)`: Retorna uma assinatura única baseada nas distâncias internas, usado para detectar duplicatas.

## Uso

### No Blender
1. Abra o Blender e vá em **Edit > Preferences > Add-ons > Install**.
2. Seleciona o arquivo `blender_addon.py` dentro da pasta `gerador_solidos`.
3. Ative o add-on e utilize o operador **Gerar, Animar e Gravar** no menu **Object** na 3D View.

### Standalone
1. Instale dependências: `pip install numpy`.
2. Coloque seu `faces.txt` na raiz do projeto `gerador_solidos/`.
3. Rode: `python standalone.py`
4. Siga as instruções para digitar o nome do sólido e aguarde a otimização.

---

**Observação**: Não modifique as funções dentro de `core/` diretamente, para manter a consistência entre o addon do Blender e o script standalone.
