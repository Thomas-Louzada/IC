import numpy as np
import ast
import os
from core.loader import carregar_solidos
from core.orientacao import corrigir_orientacao_faces
from core.geometria import calcular_d2

def verificar_distancias(vc, faces, tol=1e-3):
    """
    Verifica se as distâncias entre os vértices de cada face estão coerentes
    com a topologia esperada (definida por calcular_d2).
    """
    erros = []
    for idx_face, face in enumerate(faces):
        m = len(face)
        for i in range(m):
            for j in range(i + 1, m):
                vi, vj = vc[face[i]], vc[face[j]]
                dist2 = np.sum((vi - vj)**2)
                ref2 = calcular_d2(m, i, j)
                if abs(dist2 - ref2) > tol:
                    erros.append({
                        "face_id": idx_face,
                        "vert_indices": (face[i], face[j]),
                        "d2_real": round(dist2, 4),
                        "d2_ref": round(ref2, 4),
                        "delta": round(dist2 - ref2, 4)
                    })
    return erros

def main():
    nome_solido = input("Nome do sólido: ").strip()
    caminho_faces = "faces.txt"
    caminho_coords = f"{nome_solido}_vertices.txt"  # Arquivo com coordenadas geradas (vc)

    if not os.path.isfile(caminho_coords):
        print(f"Arquivo de coordenadas não encontrado: {caminho_coords}")
        return

    solidos = carregar_solidos(caminho_faces)
    if nome_solido not in solidos:
        print(f"Sólido '{nome_solido}' não encontrado no arquivo faces.txt")
        return

    faces_raw, _ = solidos[nome_solido]
    faces = corrigir_orientacao_faces(faces_raw)

    with open(caminho_coords, 'r') as f:
        linhas = f.readlines()
        vc = np.array([[float(x) for x in linha.strip().split()] for linha in linhas])

    erros = verificar_distancias(vc, faces, tol=1e-3)

    if not erros:
        print("Todas as distâncias estão corretas dentro da tolerância.")
    else:
        print(f"Encontrados {len(erros)} erros de distância:")
        for e in erros:
            print(f"  Face {e['face_id']}, vértices {e['vert_indices']}: real={e['d2_real']}, ref={e['d2_ref']} → delta={e['delta']}")

if __name__ == '__main__':
    main()
