import numpy as np
import math

def calcular_d2(n, i, j):
    if n == 3:
        return 1
    elif n == 4:
        return math.sqrt(2) ** 2 if abs(i - j) == 2 else 1
    elif n == 5:
        return ((1 + math.sqrt(5)) / 2) ** 2 if abs(i - j) in [2, 3] else 1
    elif n == 6:
        return (math.sqrt(3)) ** 2 if abs(i - j) == 3 else (4 if abs(i - j) == 2 else 1)
    elif n == 8:
        if abs(i - j) == 4:
            return (1 / math.sqrt(1 / 2 - math.sqrt(2) / 4)) ** 2
        elif abs(i - j) == 3:
            return (math.sqrt(math.sqrt(2) / 4 + 1 / 2) / math.sqrt(1 / 2 - math.sqrt(2) / 4)) ** 2
        elif abs(i - j) == 2:
            return (math.sqrt(2) / (2 * math.sqrt(1 / 2 - math.sqrt(2) / 4))) ** 2
        else:
            return 1
    elif n == 10:
        if abs(i - j) == 5:
            return (2 / (-1 / 2 + math.sqrt(5) / 2)) ** 2
        elif abs(i - j) == 4:
            return (2 * math.sqrt(math.sqrt(5) / 8 + 5 / 8) / (-1 / 2 + math.sqrt(5) / 2)) ** 2
        elif abs(i - j) == 3:
            return (2 * (1 / 4 + math.sqrt(5) / 4) / (-1 / 2 + math.sqrt(5) / 2)) ** 2
        elif abs(i - j) == 2:
            return (2 * math.sqrt(5 / 8 - math.sqrt(5) / 8) / (-1 / 2 + math.sqrt(5) / 2)) ** 2
        else:
            return 1

def gerar_segmentos(faces):
    segs = []
    for f in faces:
        m = len(f)
        for i in range(m):
            for j in range(i+1, m):
                d2 = calcular_d2(m, i, j)
                segs.append((f[i], f[j], d2))
    return np.array(segs, dtype=float)

def gradiente(vc, segmentos, max_step=None):
    """
    vc: array (N,3) de coordenadas
    segmentos: array de (i, j, d2)
    max_step: valor máximo para ||delta v|| em cada aresta (None = sem limite)
    """
    grad = np.zeros_like(vc)
    for seg in segmentos:
        i, j, d2 = int(seg[0]), int(seg[1]), seg[2]
        diff = vc[i] - vc[j]
        dist = np.linalg.norm(diff)
        if dist == 0:
            continue
        # gradiente sem divisão que anula o passo
        fator = 2 * (dist - math.sqrt(d2))
        delta = fator * (diff / dist)  # direção normalizada
        if max_step is not None:
            # limita o comprimento de delta
            norm_delta = np.linalg.norm(delta)
            if norm_delta > max_step:
                delta = delta * (max_step / norm_delta)
        grad[i] += delta
        grad[j] -= delta
    return grad