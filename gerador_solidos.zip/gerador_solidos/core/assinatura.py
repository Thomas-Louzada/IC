import numpy as np

def compute_distance_signature(vc):
    centroid = vc.mean(axis=0)
    y = vc - centroid
    n = len(y)
    dists = []
    for i in range(n):
        for j in range(i+1, n):
            d = np.linalg.norm(y[i] - y[j])
            dists.append(round(d, 6))
    return tuple(sorted(dists))
