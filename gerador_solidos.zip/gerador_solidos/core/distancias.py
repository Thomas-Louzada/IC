import os
import math

def calcular_distancias(vertices):
    """
    Calcula todas as distâncias entre pares de vértices.
    vertices: lista de tuplas (x, y, z)
    return: lista de distâncias
    """
    distancias = []
    n = len(vertices)
    for i in range(n):
        for j in range(i+1, n):
            dx = vertices[i][0] - vertices[j][0]
            dy = vertices[i][1] - vertices[j][1]
            dz = vertices[i][2] - vertices[j][2]
            dist = math.sqrt(dx*dx + dy*dy + dz*dz)
            distancias.append(dist)
    return distancias


def salvar_solido(nome_solido, vertices, distancias, pasta_base=None):
    # Se não passar pasta_base, salva na mesma pasta do standalone.py
    if pasta_base is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        pasta_base = os.path.join(os.path.dirname(script_dir), "solidos")
    """
    Salva os vértices e distâncias em arquivos .txt
    - Se a lista de distâncias já existir, descarta
    - Caso contrário, salva em nova entrada
    """

    # Criar pasta do sólido
    pasta_solido = os.path.join(pasta_base, nome_solido)
    os.makedirs(pasta_solido, exist_ok=True)

    # Caminho do arquivo de distâncias
    arquivo_dist = os.path.join(pasta_solido, "distancias.txt")
    arquivo_pts = os.path.join(pasta_solido, "pontos.txt")

    # Normalizar lista (para evitar diferenças de ordem)
    nova_lista = [round(d, 6) for d in distancias]  # arredonda p/ estabilidade
    nova_lista.sort()

    # Verificar duplicata
    if os.path.exists(arquivo_dist):
        with open(arquivo_dist, "r") as f:
            conteudo = f.read().splitlines()
            existentes = [line.strip() for line in conteudo if line.strip()]
            if str(nova_lista) in existentes:
                print(f"[INFO] Lista já existente para {nome_solido}, descartando.")
                return False

    # Salvar nova lista de distâncias
    with open(arquivo_dist, "a") as f:
        f.write(str(nova_lista) + "\n")

    # Salvar pontos correspondentes
    with open(arquivo_pts, "a") as f:
        f.write(str(vertices) + "\n")

    print(f"[OK] Novo sólido {nome_solido} armazenado com sucesso.")
    return True
