import os
import numpy as np
#from scipy.spatial.distance import distance

def calcular_distancias(vertices):
    distancias = []
    n = len(vertices)
    for i in range(n):
        for j in range(i + 1, n):
            d = np.linalg.norm(np.array(vertices[i]) - np.array(vertices[j]))
            distancias.append(d)
    distancias.sort()
    return distancias

def salvar_solido(nome_solido, vertices, distancias, pasta_base=None, tol=1e-6):
    if pasta_base is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        pasta_base = os.path.join(os.path.dirname(script_dir), "solidos")

    pasta_solido = os.path.join(pasta_base, nome_solido)
    os.makedirs(pasta_solido, exist_ok=True)

    dist_path = os.path.join(pasta_solido, "distancias.txt")
    pts_path = os.path.join(pasta_solido, "pontos.txt")

    # Se distancias.txt existir, comparar tolerância
    if os.path.exists(dist_path):
        with open(dist_path, "r") as f:
            blocos = f.read().strip().split("\n\n")  # separa blocos
        for bloco in blocos:
            if not bloco.strip():
                continue
            d_exist = [float(x) for x in bloco.strip().split()]
            if len(d_exist) == len(distancias):
                dif = np.max(np.abs(np.array(d_exist) - np.array(distancias)))
                if dif <= tol:
                    return False  # já existe esse mínimo

    # Salvar distâncias como um bloco separado
    with open(dist_path, "a") as f:
        f.write(" ".join(f"{d:.6f}" for d in distancias) + "\n\n")

    # Salvar pontos no formato v[n] = [x,y,z]
    with open(pts_path, "a") as f:
        f.write("Novo mínimo encontrado:\n")
        for idx, v in enumerate(vertices):
            f.write(f"v[{idx}] = [{v[0]:.6f}, {v[1]:.6f}, {v[2]:.6f}]\n")
        f.write("\n")

    return True
