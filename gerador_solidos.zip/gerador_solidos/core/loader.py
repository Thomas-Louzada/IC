import os
import ast

def carregar_solidos(arquivo):
    solidos = {}
    if not os.path.isfile(arquivo):
        raise FileNotFoundError(f"Arquivo de faces não encontrado: {arquivo}")
    with open(arquivo, 'r') as f:
        for linha in f:
            if " | n=" in linha:
                nome_e_faces, n_str = linha.split(" | n=")
                nome, faces_raw = nome_e_faces.split(" - ")
                faces = ast.literal_eval(faces_raw)
                solidos[nome.strip()] = (faces, int(n_str.strip()))
    return solidos
