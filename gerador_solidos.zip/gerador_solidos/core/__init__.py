from .geometria import calcular_d2, gerar_segmentos, gradiente
from .orientacao import corrigir_orientacao_faces
from .loader import carregar_solidos
from .assinatura import compute_distance_signature
